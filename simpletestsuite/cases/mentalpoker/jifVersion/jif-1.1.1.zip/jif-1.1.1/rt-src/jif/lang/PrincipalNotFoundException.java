package jif.lang;

public class PrincipalNotFoundException extends Exception
{
    public PrincipalNotFoundException() {
	super();
    }

    public PrincipalNotFoundException(String s) {
	super(s);
    }
}
