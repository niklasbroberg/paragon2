package jif.lang;

public interface PrincipalTranslator
{    
    Principal translate(String name);
}
