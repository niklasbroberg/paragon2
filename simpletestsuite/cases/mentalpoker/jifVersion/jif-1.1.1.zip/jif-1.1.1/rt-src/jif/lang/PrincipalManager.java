package jif.lang;

public interface PrincipalManager
{
    public boolean actsFor(Principal p1, Principal p2);
}
