package jif.lang;

import java.util.*;

public interface Policy
{    
    public boolean relabelsTo(Policy p);
}
