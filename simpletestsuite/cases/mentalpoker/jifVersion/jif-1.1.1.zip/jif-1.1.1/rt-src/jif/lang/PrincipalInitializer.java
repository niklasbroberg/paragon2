package jif.lang;

public interface PrincipalInitializer {
    public void init(Principal p);
}
