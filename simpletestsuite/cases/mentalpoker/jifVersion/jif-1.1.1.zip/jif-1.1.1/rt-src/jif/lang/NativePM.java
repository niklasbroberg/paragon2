package jif.lang;

public class NativePM
{
    public static native boolean actsFor(NativePrincipal p1, 
	    NativePrincipal p2);
}
