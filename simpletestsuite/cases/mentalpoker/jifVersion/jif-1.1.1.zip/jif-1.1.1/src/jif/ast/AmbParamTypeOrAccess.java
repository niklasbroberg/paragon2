package jif.ast;

import jif.types.*;
import jif.extension.*;
import polyglot.ast.*;
import polyglot.types.*;
import polyglot.util.*;
import polyglot.visit.*;

/** An ambiguous parameter type or array access. It has the form
 *  <code>receiver[name]</code>. 
 */
public interface AmbParamTypeOrAccess extends Receiver, Ambiguous
{
    /** Gets the prefix. */
    Receiver prefix();
    
    /** Gets the name. */
    String name();
}
