package jif.extension;


/** The Jif extension of the <code>ConstructorCall</code> node. 
 * 
 *  @see polyglot.ast.ConstructorCall
 */
public class JifConstructorCallDel extends JifJL_c
{
    public JifConstructorCallDel() {
    }
}
