package jif.ast;

import polyglot.ext.jl.ast.*;
import jif.types.*;
import jif.visit.*;
import polyglot.ast.*;
import polyglot.types.*;
import polyglot.visit.*;
import polyglot.util.*;

/** An ambiguous label node. */
public abstract class AmbLabelNode_c extends LabelNode_c
                                  implements LabelNode, Ambiguous
{
    public AmbLabelNode_c(Position pos) {
	super(pos);
    }

    /** Disambiguate the type of this node. */
    public abstract Node disambiguate(AmbiguityRemover ar)
	throws SemanticException;
}
