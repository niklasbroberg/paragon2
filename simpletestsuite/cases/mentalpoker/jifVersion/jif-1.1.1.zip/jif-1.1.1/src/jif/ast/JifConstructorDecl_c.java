package jif.ast;

import java.util.*;

import jif.types.*;
import jif.visit.JifAmbiguityRemover;
import jif.visit.LabelSubstitutionVisitor;
import polyglot.ast.*;
import polyglot.ext.jl.ast.ConstructorDecl_c;
import polyglot.types.*;
import polyglot.util.CollectionUtil;
import polyglot.util.Position;
import polyglot.util.TypedList;
import polyglot.visit.*;

/** 
 * An implementation of the <code>JifConstructor</code> interface.
 */
public class JifConstructorDecl_c extends ConstructorDecl_c implements JifConstructorDecl
{
    protected LabelNode startLabel;
    protected LabelNode returnLabel;
    protected List constraints;

    public JifConstructorDecl_c(Position pos, Flags flags, String name, LabelNode startLabel, LabelNode returnLabel, List formals, List throwTypes, List constraints, Block body) {
	super(pos, flags, name, formals, throwTypes, body);
	this.startLabel = startLabel;
        this.returnLabel = returnLabel;
	this.constraints = TypedList.copyAndCheck(constraints, ConstraintNode.class, true);
    }

    public LabelNode startLabel() {
	return this.startLabel;
    }

    public JifConstructorDecl startLabel(LabelNode startLabel) {
	JifConstructorDecl_c n = (JifConstructorDecl_c) copy();
	n.startLabel = startLabel;
	return n;
    }

    public LabelNode returnLabel() {
        return this.returnLabel;
    }

    public JifConstructorDecl returnLabel(LabelNode returnLabel) {
	JifConstructorDecl_c n = (JifConstructorDecl_c) copy();
	n.returnLabel = returnLabel;
	return n;
    }

    public List constraints() {
	return this.constraints;
    }

    public JifConstructorDecl constraints(List constraints) {
	JifConstructorDecl_c n = (JifConstructorDecl_c) copy();
	n.constraints = TypedList.copyAndCheck(constraints, ConstraintNode.class, true);
	return n;
    }

    protected JifConstructorDecl_c reconstruct(LabelNode startLabel, LabelNode returnLabel, List formals, List throwTypes, List constraints, Block body) {
	if (startLabel != this.startLabel || returnLabel != this.returnLabel || !CollectionUtil.equals(constraints, this.constraints)) {
	    JifConstructorDecl_c n = (JifConstructorDecl_c) copy();
	    n.startLabel = startLabel;
	    n.returnLabel = returnLabel;
	    n.constraints = TypedList.copyAndCheck(constraints, ConstraintNode.class, true);
	    return (JifConstructorDecl_c) n.reconstruct(formals, throwTypes, body);
	}

	return (JifConstructorDecl_c) super.reconstruct(formals, throwTypes, body);
    }

    public Node visitChildren(NodeVisitor v) {
        LabelNode startLabel = (LabelNode) visitChild(this.startLabel, v);
        LabelNode returnLabel = (LabelNode) visitChild(this.returnLabel, v);
        List formals = visitList(this.formals, v);
        List throwTypes = visitList(this.throwTypes, v);
	List constraints = visitList(this.constraints, v);
	Block body = (Block) visitChild(this.body, v);
	return reconstruct(startLabel, returnLabel, formals, throwTypes, constraints, body);
    }

    /**
     * Build the constructor instance, and make sure that the arg labels are correct.
     */
    public Node buildTypes(TypeBuilder tb) throws SemanticException {
        JifTypeSystem ts = (JifTypeSystem)tb.typeSystem();

        List l = new ArrayList(formals.size());
        ArrayList argLabels = new ArrayList(formals.size());
        for (int i = 0; i < formals.size(); i++) {
            Formal f = (Formal)formals.get(i);
            l.add(ts.unknownType(position()));
            ArgLabel al = ts.argLabel(f.position(), i, true, f.name());
            argLabels.add(i, al);
            ((JifLocalInstance)f.localInstance()).setLabel(al);
        }

        List m = new ArrayList(throwTypes().size());
        for (int i = 0; i < throwTypes().size(); i++) {
            m.add(ts.unknownType(position()));
        }

        ConstructorInstance ci = ts.jifConstructorInstance(position(), ts.Object(),
                                                        Flags.NONE, 
                                                        null, false,
                                                        null, false, 
                                                        l, m, 
                                                        Collections.EMPTY_LIST, 
                                                        argLabels);
        return constructorInstance(ci);
    }

    protected ConstructorInstance makeConstructorInstance(ClassType ct, TypeSystem ts)
    	throws SemanticException
    {
	JifTypeSystem jts = (JifTypeSystem) ts;
	List formalTypes = new LinkedList();
	List excTypes = new LinkedList();

        JifConstructorInstance jci = (JifConstructorInstance)this.constructorInstance(); 
        int ind = 0;
        for (Iterator i = formals.iterator(); i.hasNext(); ) {
            Formal f = (Formal) i.next();            
            ArgLabel al = (ArgLabel)jci.argLabels().get(ind);            
            
            // set the label of the formal to the appropriate arg label, i.e.
            // al.
            JifLocalInstance li = (JifLocalInstance)f.localInstance();
            li.setLabel(al);
            ind++;
        }

	int index = 0;
	for (Iterator i = this.formals.iterator(); i.hasNext(); ) {
	    Formal f = (Formal) i.next();
	    Type t = f.declType();
	    if (jts.isLabeled(t)) 
		formalTypes.add(t);
	    else 
		formalTypes.add(jts.labeledType(t.position(), t, 
			                     jts.defaultArgLabel(t.position(),
						                 index++,
							         f.name())));						              
	}

	Flags flags = this.flags;
	if (ct.flags().isInterface()) {
	    flags = flags.Public().Abstract();
	}

	Label Li; // start label
        boolean isDefaultStartLabel = false;
	if (this.startLabel == null) {
	    Li = jts.defaultStartLabel(position(), name);
            isDefaultStartLabel = true;
        } 
	else {
	    Li = this.startLabel.label();
        }
    
	Label Lr; // return label
        boolean isDefaultReturnLabel = false;
	if (this.returnLabel == null) { 
	    Lr = jts.defaultReturnLabel(this);
            isDefaultReturnLabel = true;
        }
	else { 
	    Lr = this.returnLabel.label();
        }
    
	for (Iterator i = this.throwTypes().iterator(); i.hasNext(); ) {
	    TypeNode tn = (TypeNode) i.next();
	    Type xt = tn.type();
	    if (!jts.isLabeled(xt)) {
		// default exception label is the return label
		xt = jts.labeledType(xt.position(), xt, Lr);
	    }
	    
	    excTypes.add(xt);
	}

	List constraints = new ArrayList(this.constraints.size());
	for (Iterator i = this.constraints.iterator(); i.hasNext(); ) {
	    ConstraintNode cn = (ConstraintNode) i.next();
	    constraints.add(cn.constraint());
	}

	return jts.jifConstructorInstance(position(), ct, flags,
		Li, isDefaultStartLabel, Lr, isDefaultReturnLabel,
                formalTypes, excTypes, constraints, jci.argLabels());
    }

    public NodeVisitor disambiguateEnter(AmbiguityRemover ar) throws SemanticException {
        JifAmbiguityRemover jar = (JifAmbiguityRemover)ar;
        jar.setProcedureFormals(this.formals);
        return super.disambiguateEnter(ar);
    }

    public Node disambiguate(AmbiguityRemover ar) throws SemanticException {
        Node n = super.disambiguate(ar);
        if (ar.kind() == AmbiguityRemover.ALL) {
            // the signature has been disambiguated, that is, the correct
            // arg labels are in place. So we can rewrite the declaration body
            // to have the correct arg labels.
            JifConstructorInstance ci =
                (JifConstructorInstance) ((JifConstructorDecl_c)n).constructorInstance();
            List argLabels = ci.nonSignatureArgLabels();
            LabelSubstitutionVisitor v = new LabelSubstitutionVisitor(new SignatureArgSubstitution(argLabels), false);
            n = n.visitChildren(v);
        }
        return n;
    }
    public Node typeCheck(TypeChecker tc) throws SemanticException {
	Node n = super.typeCheck(tc);    
        JifConstructorDecl_c jcd = (JifConstructorDecl_c)n;
        jcd.checkConstructorCall(tc);
    
        return jcd;
    }
    
    /**
     * Checks that if there is an explicit constructor call in the constructor
     * body that the call is alright.
     * 
     * In particular, if this is a java class or one of the ancestors of this 
     * class is "untrusted" then the explicit constructor call must be 
     * the first statement in the constructor body.
     * 
     * Moreover, if this is a Jif class, but the superclass is not a Jif class,
     * then first statement must be a default constructor call.
     * @throws SemanticException
     */
    private void checkConstructorCall(TypeChecker tc) throws SemanticException {
        
        JifTypeSystem ts = (JifTypeSystem)tc.typeSystem();

        ClassType ct = tc.context().currentClass();

        // ignore java.lang.Object
        if (ts.equals(ct, ts.Object())) 
            return;

        ClassType untrusted = ts.hasUntrustedAncestor(ct);
        if (!ts.isJifClass(ct) || untrusted != null) {
            // the first statement of the body had better be an explicit
            // constructor call
            StringBuffer message = new StringBuffer("The first statement " + 
                               "of the constructor must be a constructor " +
                               "call");               
            if (untrusted != null) {
                message.append(", as the ancestor ");
                message.append(untrusted.fullName());
                message.append(" is not trusted");
            }
            message.append(".");
            checkFirstStmtConstructorCall(message.toString(), false);
        }
        
        if (ts.isJifClass(ct) && !ts.isJifClass(ct.superType())) {
            // this is a Jif class, but it's super class is not.
            // the first statement must be a default constructor call
            checkFirstStmtConstructorCall("The first statement of the " +
                           "constructor must be a default constructor call, " +
                           "as the superclass is not a Jif class", 
                           true);
        }
    }
    
    private void checkFirstStmtConstructorCall(String message, 
                                               boolean mustBeDefaultCall) 
                                 throws SemanticException {
        if (body().statements().size() < 1) {
            throw new SemanticException("Empty constructor body.",
                                        position());
        }
        Stmt s = (Stmt)body().statements().get(0);
        if (!(s instanceof ConstructorCall)) {
            throw new SemanticException(message, position());
        }
        else if (mustBeDefaultCall) {
            ConstructorCall cc = (ConstructorCall)s;
            if (cc.arguments().size() > 0) {
                throw new SemanticException(message, position());                
            }
        }
        
    }
}
