package jif.ast;

import java.util.*;

import jif.types.*;
import jif.visit.JifAmbiguityRemover;
import jif.visit.LabelSubstitutionVisitor;
import polyglot.ast.*;
import polyglot.ext.jl.ast.MethodDecl_c;
import polyglot.types.*;
import polyglot.util.CollectionUtil;
import polyglot.util.Position;
import polyglot.util.TypedList;
import polyglot.visit.AmbiguityRemover;
import polyglot.visit.NodeVisitor;
import polyglot.visit.TypeBuilder;

/** An implementation of the <code>JifMethod</code> interface.
 */
public class JifMethodDecl_c extends MethodDecl_c implements JifMethodDecl
{
    protected LabelNode startLabel;
    protected LabelNode returnLabel;
    protected List constraints;

    public JifMethodDecl_c(Position pos, Flags flags, TypeNode returnType,
	    String name, LabelNode startLabel, List formals, LabelNode returnLabel,
	    List throwTypes, List constraints, Block body) {
	super(pos, flags, returnType, name, formals, throwTypes, body);
	this.startLabel = startLabel;
	this.returnLabel = returnLabel;
	this.constraints = TypedList.copyAndCheck(constraints, 
		ConstraintNode.class, true);
    }

    public LabelNode startLabel() {
	return this.startLabel;
    }

    public JifMethodDecl startLabel(LabelNode startLabel) {
	JifMethodDecl_c n = (JifMethodDecl_c) copy();
	n.startLabel = startLabel;
	return n;
    }

    public LabelNode returnLabel() {
	return this.returnLabel;
    }

    public JifMethodDecl returnLabel(LabelNode returnLabel) {
	JifMethodDecl_c n = (JifMethodDecl_c) copy();
	n.returnLabel = returnLabel;
	return n;
    }

    public List constraints() {
	return this.constraints;
    }

    public JifMethodDecl constraints(List constraints) {
	JifMethodDecl_c n = (JifMethodDecl_c) copy();
	n.constraints = TypedList.copyAndCheck(constraints, ConstraintNode.class, true);
	return n;
    }

    public Node visitChildren(NodeVisitor v) {
        TypeNode returnType = (TypeNode) visitChild(this.returnType, v);
	LabelNode startLabel = (LabelNode) visitChild(this.startLabel, v);
        List formals = visitList(this.formals, v);
	LabelNode returnLabel = (LabelNode) visitChild(this.returnLabel, v);
        List throwTypes = visitList(this.throwTypes, v);
	List constraints = visitList(this.constraints, v);
	Block body = (Block) visitChild(this.body, v);
	return reconstruct(returnType, startLabel, formals, returnLabel, throwTypes, constraints, body);
    }

    protected JifMethodDecl_c reconstruct(TypeNode returnType, LabelNode startLabel, List formals, LabelNode returnLabel, List throwTypes, List constraints, Block body) {
      if (startLabel != this.startLabel || returnLabel != this.returnLabel || ! CollectionUtil.equals(constraints, this.constraints)) {
          JifMethodDecl_c n = (JifMethodDecl_c) copy();
          n.startLabel = startLabel;
          n.returnLabel = returnLabel;
          n.constraints = TypedList.copyAndCheck(constraints, ConstraintNode.class, true);
          return (JifMethodDecl_c) n.reconstruct(returnType, formals, throwTypes, body);
      }

      return (JifMethodDecl_c) super.reconstruct(returnType, formals, throwTypes, body);
    }

    /**
     * Build the method instance and make sure that the arg labels are correct.
     */
    public Node buildTypes(TypeBuilder tb) throws SemanticException {
        JifTypeSystem ts = (JifTypeSystem)tb.typeSystem();

        List l = new ArrayList(formals.size());
        ArrayList argLabels = new ArrayList(formals.size());
        for (int i = 0; i < formals.size(); i++) {
            Formal f = (Formal)formals.get(i);
            l.add(ts.unknownType(position()));
            Label al = ts.argLabel(f.position(), i, true, f.name());
            argLabels.add(i, al);            
            JifLocalInstance jli = (JifLocalInstance)f.localInstance();
            jli.setLabel(al);
        }


        List m = new ArrayList(throwTypes().size());
        for (int i = 0; i < throwTypes().size(); i++) {
          m.add(ts.unknownType(position()));
        }

        MethodInstance mi = ts.jifMethodInstance(position(), ts.Object(),
                                              Flags.NONE,
                                              ts.unknownType(position()),
                                              name, null, false,
                                              l, null, false, m, 
                                              Collections.EMPTY_LIST, argLabels);
        return methodInstance(mi);
    }
    protected MethodInstance makeMethodInstance(ClassType ct, TypeSystem ts)
    	throws SemanticException 
    {
	JifTypeSystem jts = (JifTypeSystem) ts;
	List formalTypes = new LinkedList();
	List excTypes = new LinkedList();

        JifMethodInstance jmi = (JifMethodInstance)this.methodInstance();
        int ind = 0;
        for (Iterator i = formals.iterator(); i.hasNext(); ) {
            Formal f = (Formal) i.next();            
            ArgLabel al = jmi.getArgLabel(ind);            

            // set the label of the formal to the appropriate arg label, i.e.
            // al.
            JifLocalInstance li = (JifLocalInstance)f.localInstance();
            li.setLabel(al);
            ind++;
        }

        int index = 0;
        for (Iterator i = this.formals.iterator(); i.hasNext(); ) {
            Formal f = (Formal) i.next();
            Type t = f.declType();
            if (jts.isLabeled(t)) 
                formalTypes.add(t);
            else 
                formalTypes.add(jts.labeledType(t.position(), t, 
                                             jts.defaultArgLabel(t.position(),
                                                                 index++, 
                                                                f.name())));						              
        }

        Flags flags = this.flags();
        if (ct.flags().isInterface()) {
            flags = flags.Public().Abstract();
        }

        Label Li; // start label
        boolean isDefaultStartLabel = false;
        if (this.startLabel == null) {
            Li = jts.defaultStartLabel(this.position(), this.name);
            isDefaultStartLabel = true;
        }
        else {
            Li = this.startLabel.label();
        }

        Label Lr; // return label
        boolean isDefaultReturnLabel = false;
        if (this.returnLabel == null) { 
            Lr = jts.defaultReturnLabel(this);
            isDefaultReturnLabel = true;
        }
        else {
            Lr = this.returnLabel.label();
        }
        
        for (Iterator i = this.throwTypes().iterator(); i.hasNext(); ) {
            TypeNode tn = (TypeNode) i.next();
            Type xt = tn.type();
            if (!jts.isLabeled(xt)) {
                // default exception label is the return label
                xt = jts.labeledType(xt.position(), xt, Lr);
            }

            excTypes.add(xt);
        }

        Type declReturnType = this.returnType.type();
        if (! declReturnType.isVoid() && ! jts.isLabeled(declReturnType)) {
            declReturnType = jts.labeledType(this.returnType.position(),
                    declReturnType, jts.defaultReturnValueLabel(this));
        }

        List constraints = new ArrayList(this.constraints.size());
        for (Iterator i = this.constraints.iterator(); i.hasNext(); ) {
            ConstraintNode cn = (ConstraintNode) i.next();
            constraints.add(cn.constraint());
        }


        return jts.jifMethodInstance(position(), ct, flags, declReturnType,
                name, Li, isDefaultStartLabel, formalTypes, 
                Lr, isDefaultReturnLabel, excTypes, constraints, jmi.argLabels());
    }
    
    public NodeVisitor disambiguateEnter(AmbiguityRemover ar) throws SemanticException {
        JifAmbiguityRemover jar = (JifAmbiguityRemover)ar;
        jar.setProcedureFormals(this.formals);
        return super.disambiguateEnter(ar);
    }

    public Node disambiguate(AmbiguityRemover ar) throws SemanticException {
        Node n = super.disambiguate(ar);
        if (ar.kind() == AmbiguityRemover.ALL) {
            // the signature has been disambiguated, that is, the correct
            // arg labels are in place. So we can rewrite the declaration body
            // to have the correct arg labels.
            JifMethodInstance mi =
                (JifMethodInstance) ((JifMethodDecl_c)n).methodInstance();
            List argLabels = mi.nonSignatureArgLabels();
            LabelSubstitutionVisitor v = new LabelSubstitutionVisitor(new SignatureArgSubstitution(argLabels), false);
            n = n.visitChildren(v);

        }
        return n;
    }    
}

/**
 *  This class substitutes all signature ArgLabels, DynamicArgLabels and
 * ArgPrincipals in a procedure declaration with appropriate non-signature
 * labels/principals.
 */
class SignatureArgSubstitution extends ArgLabelSubstitution {
    public SignatureArgSubstitution(List nonSigArgLabels) {
        super(nonSigArgLabels, false);
    }
    public Label substLabel(Label L) {
        L = super.substLabel(L);

        if (L instanceof DynamicArgLabel) {
            DynamicArgLabel dal = (DynamicArgLabel)L;
            JifTypeSystem jts = (JifTypeSystem)dal.typeSystem();
            L = jts.dynamicArgLabel(dal.position(), 
                                    dal.uid(), 
                                    dal.name(), 
                                    dal.label(), 
                                    dal.index(), 
                                    false);
        }
        return L;
    }

    public Principal substPrincipal(Principal p) {
        p = super.substPrincipal(p);
        if (p instanceof ArgPrincipal) {
            ArgPrincipal dap = (ArgPrincipal)p;
            JifTypeSystem jts = (JifTypeSystem)dap.typeSystem();
            p = jts.argPrincipal(dap.position(),
                                 dap.uid(),
                                 dap.name(),
                                 dap.label(),
                                 dap.index(),
                                 false);
        }
        return p;
    }
}
