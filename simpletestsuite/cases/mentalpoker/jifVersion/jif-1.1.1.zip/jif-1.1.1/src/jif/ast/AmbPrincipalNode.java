package jif.ast;

import polyglot.ast.*;

/** An ambiguous principal node. 
 */
public interface AmbPrincipalNode extends PrincipalNode, Ambiguous {
    /** Getts the name. */
    String name();
}
