package jif.ast;

import jif.types.*;

/** A canonical label node. 
 */
public interface CanonicalLabelNode extends LabelNode {
}
