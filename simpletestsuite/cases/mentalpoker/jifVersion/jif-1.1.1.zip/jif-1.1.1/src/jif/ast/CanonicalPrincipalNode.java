package jif.ast;

import jif.types.*;

/** Canonical principal node. 
 */
public interface CanonicalPrincipalNode extends PrincipalNode {
}
