package jif.ast;

import polyglot.ast.Node;
import polyglot.ast.TypeNode;
import polyglot.ext.jl.ast.Formal_c;
import polyglot.types.*;
import polyglot.util.Position;
import polyglot.visit.AmbiguityRemover;
import polyglot.visit.TypeBuilder;

/**
 * 
 */
public class JifFormal_c extends Formal_c {

    public JifFormal_c(Position pos, Flags flags, TypeNode type, String name) {
        super(pos, flags, type, name);
    }

    public Node buildTypes(TypeBuilder tb) throws SemanticException {
        JifFormal_c n = (JifFormal_c) super.buildTypes(tb);

        LocalInstance li = n.localInstance().flags(flags());
        return n.localInstance(li);
    }
    
    /* Perform an imperative update to the local instance.
     */
    public Node disambiguate(AmbiguityRemover ar) throws SemanticException {
        if (declType().isCanonical() && ! localInstance().type().isCanonical()) {
            TypeSystem ts = ar.typeSystem();
            localInstance().setType(declType());
        }   

        return this;
    }

}
