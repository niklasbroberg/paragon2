package jif.ast;

import java.util.*;

import jif.types.*;
import polyglot.ast.ClassBody;
import polyglot.ast.Node;
import polyglot.ast.TypeNode;
import polyglot.ext.jl.ast.ClassDecl_c;
import polyglot.ext.param.types.MuPClass;
import polyglot.types.*;
import polyglot.util.*;
import polyglot.visit.*;

/** An implementation of the <code>JifClassDecl</code> interface.
 */
public class JifClassDecl_c extends ClassDecl_c implements JifClassDecl
{
    protected List params;
    protected boolean invariant; //"this" label is invariant
    protected List authority;

    public JifClassDecl_c(Position pos, Flags flags, String name,
	    List params, boolean inv, TypeNode superClass, List interfaces,
	    List authority, ClassBody body) {
	super(pos, flags, name, superClass, interfaces, body);
	this.params = TypedList.copyAndCheck(params, ParamDecl.class, true);
	this.authority = TypedList.copyAndCheck(authority, PrincipalNode.class, true);
	this.invariant = inv;
    }

    public List params() {
	return this.params;
    }

    public JifClassDecl params(List params) {
	JifClassDecl_c n = (JifClassDecl_c) copy();
	n.params = TypedList.copyAndCheck(params, ParamDecl.class, true);
	return n;
    }

    public List authority() {
	return this.authority;
    }

    public JifClassDecl authority(List authority) {
	JifClassDecl_c n = (JifClassDecl_c) copy();
	n.authority = TypedList.copyAndCheck(authority, PrincipalNode.class, true);
	return n;
    }

    protected JifClassDecl_c reconstruct(List params, TypeNode superClass, List interfaces, List authority, ClassBody body) {
	if (! CollectionUtil.equals(params, this.params) || ! CollectionUtil.equals(authority, this.authority)) {
	    JifClassDecl_c n = (JifClassDecl_c) copy();
	    n.params = TypedList.copyAndCheck(params, ParamDecl.class, true);
	    n.authority = TypedList.copyAndCheck(authority, PrincipalNode.class, true);
	    return (JifClassDecl_c) n.reconstruct(superClass, interfaces, body);
	}

	return (JifClassDecl_c) super.reconstruct(superClass, interfaces, body);
    }

    public Node visitChildren(NodeVisitor v) {
	List params = visitList(this.params, v);
	TypeNode superClass = (TypeNode) visitChild(this.superClass, v);
	List interfaces = visitList(this.interfaces, v);
	List authority = visitList(this.authority, v);
	ClassBody body = (ClassBody) visitChild(this.body, v);
	return reconstruct(params, superClass, interfaces, authority, body);
    }

    public Context enterScope(Context c) {
        JifContext A = (JifContext) c;
        JifTypeSystem ts = (JifTypeSystem) A.typeSystem();

        JifParsedPolyType ct = (JifParsedPolyType) this.type;
        ClassType inst = ct;

        A = (JifContext) A.pushClass(ct, inst);

        A.setAuthority(new HashSet(ct.authority()));

        for (Iterator i = ct.params().iterator(); i.hasNext(); ) {
            ParamInstance pi = (ParamInstance) i.next();
            A.addVariable(pi);
        }

        return A;
    }

    public Node buildTypes(TypeBuilder tb) throws SemanticException {
        JifClassDecl_c n = (JifClassDecl_c) super.buildTypes(tb);
        n.addParams((JifTypeSystem) tb.typeSystem());
        return n;
    }

    public Node disambiguate(AmbiguityRemover ar) throws SemanticException {
        Node n = super.disambiguate(ar);
	
	((JifClassDecl_c)n).addAuth((JifTypeSystem) ar.typeSystem());

        if (ar.kind() == AmbiguityRemover.SIGNATURES) {
            // Super type is disambiguated now--can add params.
            if (invariant) {
                JifParsedPolyType ct = (JifParsedPolyType) this.type;
                Type st = ct.superType();

                if (st instanceof JifClassType) {
                    JifClassType jst = (JifClassType) st;
                    if (jst.invariant()) {
                        Type newSt = jst.setInvariantThis(ct.thisLabel());
                        if (st != newSt) 
                            ct.superType(newSt);
                    }
                }
            }	
        }

        return n;
    }

    public Node addMembers(AddMemberVisitor tb) throws SemanticException {
	JifClassDecl_c n = (JifClassDecl_c) super.addMembers(tb);
	//n.addAuth((JifTypeSystem) tb.typeSystem());
	return n;
    }

    public JifClassDecl type(Type type) {
        JifClassDecl_c n = (JifClassDecl_c) copy();
        n.type = (ParsedClassType) type;
        return n;
    }

    protected void addAuth(JifTypeSystem ts) throws SemanticException {
	JifParsedPolyType ct = (JifParsedPolyType) this.type;
	Set names = new HashSet(params.size());

	for (Iterator i = authority.iterator(); i.hasNext(); ) {
	    PrincipalNode p = (PrincipalNode) i.next();
	    ct.addAuthority(p.principal());
	}
    }

    protected void addParams(JifTypeSystem ts) throws SemanticException {
	JifParsedPolyType ct = (JifParsedPolyType) this.type;
        MuPClass pc = ts.mutablePClass(ct.position());

        ct.setInstantiatedFrom(pc);
        pc.clazz(ct);

	Set names = new HashSet(params.size());

	for (Iterator i = params.iterator(); i.hasNext(); ) {
	    ParamDecl p = (ParamDecl) i.next();
	    ct.addParam(p.paramInstance());
	    //check for renaming error
	    if (names.contains(p.name()) )
		throw new SemanticException("Redefined Parameter Error.",
			p.position());
	    else
		names.add(p.name());
	}

	//"this" label attached to ClassType. Essentially, it is a
	//covariant label parameter.
        if (ct.thisLabel()==null) {
	    if (!invariant)
		ct.thisLabel(ts.freshCovariantLabel(position(), "this").
                         description("label of the reference \"this\" in class " + ct.name()));
	    else
		ct.thisLabel(ts.paramLabel(position(), new UID("this")).
                         description("label of the reference \"this\" in class " + ct.name()) );
	}

	if (invariant) {
	    ct.invariant(true);

            /* NJN -- not necessary

	    //create a new param instance
	    ParamLabel pl = (ParamLabel) ct.thisLabel();
	    ct.addParam(ts.paramInstance(this.position(), ct, 
			ParamInstance.INVARIANT_LABEL, pl.uid() ) );

                        */
            /*
	    Type st = ct.superType();
	    if (st instanceof JifClassType) {
		JifClassType jst = (JifClassType) st;
		if (jst.invariant()) {
		    Type newSt = jst.setInvariantThis(ct.thisLabel());
		    if (st != newSt) 
			ct.superType(newSt);
		}
	    }
            */
	}	
    }

    public void prettyPrintHeader(CodeWriter w, PrettyPrinter tr) {
        if (flags.isInterface()) {
            w.write(flags.clearInterface().clearAbstract().translate());
            w.write("interface ");
        }
        else {
            w.write(flags.translate());
            w.write("class ");
        }

        w.write(name);

        if (! params.isEmpty()) {
            w.write("[");
            for (Iterator i = params.iterator(); i.hasNext(); ) {
                ParamDecl p = (ParamDecl) i.next();
                print(p, w, tr);
                if (i.hasNext()) {
                    w.write(",");
                    w.allowBreak(0, " ");
                }
            }
            w.write("]");
        }

        if (invariant) {
            w.write(" (invariant)");
        }

        if (! authority.isEmpty()) {
            w.write(" authority(");
            for (Iterator i = authority.iterator(); i.hasNext(); ) {
                PrincipalNode p = (PrincipalNode) i.next();
                print(p, w, tr);
                if (i.hasNext()) {
                    w.write(",");
                    w.allowBreak(0, " ");
                }
            }
            w.write(")");
        }

        if (superClass() != null) {
            w.write(" extends ");
            print(superClass(), w, tr);
        }

        if (! interfaces.isEmpty()) {
            if (flags.isInterface()) {
                w.write(" extends ");
            }
            else {
                w.write(" implements ");
            }

            for (Iterator i = interfaces().iterator(); i.hasNext(); ) {
                TypeNode tn = (TypeNode) i.next();
                print(tn, w, tr);

                if (i.hasNext()) {
                    w.write (", ");
                }
            }
        }

        w.write(" {");
    }

    public Node typeCheck(TypeChecker tc) throws SemanticException {
        // The invariantness of the class must agree with its super class.
        // At the moment, this means that we can't have any invariant classes.
        Type superClass = null;
        if (this.superClass() != null) {
            superClass = this.superClass().type();
        }
        if (superClass != null) {
            if (this.invariant != ((JifClassType)superClass.toClass()).invariant()) {
                throw new SemanticException("Covariant classes other than " +
                     "Object can only be " +
                    "extended with covariant classes.", 
                    this.position());                
            }
        }
                
        return super.typeCheck(tc);
    }

    public void translate(CodeWriter w, Translator tr) {
        throw new InternalCompilerError("cannot translate " + this);
    }
}
