package jif.ast;

import jif.types.JifClassType;
import jif.types.Label;
import polyglot.ast.Node;
import polyglot.types.Context;
import polyglot.types.SemanticException;
import polyglot.util.CodeWriter;
import polyglot.util.Position;
import polyglot.visit.AmbiguityRemover;
import polyglot.visit.PrettyPrinter;

/** An implementation of the <code>AmbThisLabelNode</code> interface. 
 */
public class AmbThisLabelNode_c extends AmbLabelNode_c
                               implements AmbThisLabelNode
{
    public AmbThisLabelNode_c(Position pos) {
	super(pos);
    }

    public String toString() {
	return "this{amb}";
    }

    /** Disambiguates the type of this node by finding the correct label for
     * "this". 
     */
    public Node disambiguate(AmbiguityRemover sc) throws SemanticException {
	Context c = sc.context();
    
        if (c.inStaticContext()) {
            throw new SemanticException("The label \"this\" cannot be used " +
                "in a static context.", position());
        }
        
	JifNodeFactory nf = (JifNodeFactory) sc.nodeFactory();

	JifClassType ct = (JifClassType) c.currentClass();
	Label THIS = ct.thisLabel();

        return nf.CanonicalLabelNode(position(), THIS);
    }

    public void prettyPrint(CodeWriter w, PrettyPrinter tr) {
        w.write("this");
    }
}
