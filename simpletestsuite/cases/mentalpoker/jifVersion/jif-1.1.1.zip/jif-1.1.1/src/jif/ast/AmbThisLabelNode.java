package jif.ast;

import polyglot.ast.*;

/** An ambigous <code>this</code> label node. 
 */
public interface AmbThisLabelNode extends LabelNode, Ambiguous {
}
