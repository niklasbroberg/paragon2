./binder.py | grep -v "\-\-"
